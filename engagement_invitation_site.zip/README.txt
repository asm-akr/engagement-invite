# Engagement Invitation Website

This is a standalone copy of the Canva invitation as a responsive web page.

Files:
- index.html — the website
- invitation.webp — the invitation artwork

The QR code area is clickable and opens the same directions link embedded in the original invitation.

Free hosting options include GitHub Pages or another static-site host. A custom .com domain is separate and normally costs money.
